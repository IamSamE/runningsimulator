A Pen created at CodePen.io. You can find this one at https://codepen.io/Samatar981/pen/LgrZXz.

 I've seen alot of different to do list web apps and all used newer JS libraries which is fine but I've been working on bettering my understanding of plain JavaScript and this is what I created.